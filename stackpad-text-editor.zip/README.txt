StackPad — Undo & Redo Text Editor

FILES
- index.html: page structure
- style.css: responsive layout and styling
- script.js: undo/redo stack behavior

RUN LOCALLY
1. Download and extract stackpad-text-editor.zip.
2. Keep all three files in the same folder.
3. Open index.html in a browser.

HOST ONLINE
Upload index.html, style.css, and script.js together to a static hosting service
such as GitHub Pages, Netlify, or Vercel. Make sure index.html is at the published
site's root and all three files stay together.

HOW IT DEMONSTRATES A STACK
- Editing pushes a previous text snapshot onto the Undo Stack.
- Undo pops the latest previous snapshot and pushes the current text onto Redo.
- Redo pops the latest redo snapshot and pushes the current text onto Undo.
- A new edit clears the Redo Stack.
- The top of each stack is shown first in the visual panels.
