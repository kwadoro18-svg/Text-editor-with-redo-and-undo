const editor = document.getElementById('editor');
const undoBtn = document.getElementById('undoBtn');
const redoBtn = document.getElementById('redoBtn');
const clearBtn = document.getElementById('clearBtn');
const undoStackEl = document.getElementById('undoStack');
const redoStackEl = document.getElementById('redoStack');
const undoCount = document.getElementById('undoCount');
const redoCount = document.getElementById('redoCount');
const wordCount = document.getElementById('wordCount');
const charCount = document.getElementById('charCount');

// Each stack stores complete text snapshots. The final array item is the top.
const undoStack = [];
const redoStack = [];
let currentText = '';
let typingTimer = null;
let lastSavedText = '';
const MAX_HISTORY = 30;

function pushState(stack, value) {
  stack.push(value);
  if (stack.length > MAX_HISTORY) stack.shift();
}

function saveCurrentState() {
  if (editor.value === currentText) return;
  pushState(undoStack, currentText);
  currentText = editor.value;
  redoStack.length = 0; // A new edit invalidates the redo history.
  render();
}

function renderStack(element, stack, type) {
  element.innerHTML = '';
  if (stack.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-stack';
    empty.innerHTML = '<span>↥</span><strong>Stack is empty</strong><small>' +
      (type === 'undo' ? 'Make an edit to add a state' : 'Undo an edit to add a state') +
      '</small>';
    element.appendChild(empty);
    return;
  }

  // Show newest/top state first, matching the next state that will be popped.
  const visible = stack.slice(-4).reverse();
  visible.forEach((text, index) => {
    const item = document.createElement('div');
    item.className = 'stack-item' + (index === 0 ? ' top' : '');
    const number = stack.length - index;
    const preview = text.replace(/\s+/g, ' ').trim();
    item.innerHTML =
      '<span class="item-index">' + number + '</span>' +
      '<div class="item-copy"><strong>' + (index === 0 ? 'Most recent state' : 'Saved state') +
      '</strong><small></small></div>' +
      (index === 0 ? '<span class="top-tag">TOP</span>' : '');
    item.querySelector('small').textContent = preview || '(empty text)';
    element.appendChild(item);
  });

  if (stack.length > 4) {
    const more = document.createElement('div');
    more.style.cssText = 'text-align:center;color:#9ba3b2;font-size:9px;padding-top:2px';
    more.textContent = '+ ' + (stack.length - 4) + ' older states';
    element.appendChild(more);
  }
}

function render() {
  undoCount.textContent = undoStack.length;
  redoCount.textContent = redoStack.length;
  undoBtn.disabled = undoStack.length === 0;
  redoBtn.disabled = redoStack.length === 0;
  renderStack(undoStackEl, undoStack, 'undo');
  renderStack(redoStackEl, redoStack, 'redo');

  const text = editor.value;
  const trimmed = text.trim();
  const words = trimmed ? trimmed.split(/\s+/).length : 0;
  wordCount.textContent = words + (words === 1 ? ' word' : ' words');
  charCount.textContent = text.length + (text.length === 1 ? ' character' : ' characters');
}

function undo() {
  if (!undoStack.length) return;
  pushState(redoStack, editor.value);
  editor.value = undoStack.pop();
  currentText = editor.value;
  lastSavedText = currentText;
  render();
}

function redo() {
  if (!redoStack.length) return;
  pushState(undoStack, editor.value);
  editor.value = redoStack.pop();
  currentText = editor.value;
  lastSavedText = currentText;
  render();
}

editor.addEventListener('input', () => {
  // Save the state from before this edit. A short delay groups rapid keystrokes
  // into one practical undo step rather than creating one stack item per key.
  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => {
    saveCurrentState();
    lastSavedText = editor.value;
  }, 450);
  render();
});

editor.addEventListener('blur', () => {
  clearTimeout(typingTimer);
  saveCurrentState();
  lastSavedText = editor.value;
});

undoBtn.addEventListener('click', () => {
  clearTimeout(typingTimer);
  saveCurrentState();
  undo();
});
redoBtn.addEventListener('click', () => {
  clearTimeout(typingTimer);
  saveCurrentState();
  redo();
});
clearBtn.addEventListener('click', () => {
  clearTimeout(typingTimer);
  if (editor.value === '') return;
  pushState(undoStack, editor.value);
  editor.value = '';
  currentText = '';
  redoStack.length = 0;
  render();
  editor.focus();
});

document.addEventListener('keydown', (event) => {
  const key = event.key.toLowerCase();
  if ((event.ctrlKey || event.metaKey) && key === 'z' && !event.shiftKey) {
    event.preventDefault();
    clearTimeout(typingTimer);
    saveCurrentState();
    undo();
  } else if ((event.ctrlKey || event.metaKey) &&
             (key === 'y' || (key === 'z' && event.shiftKey))) {
    event.preventDefault();
    clearTimeout(typingTimer);
    saveCurrentState();
    redo();
  }
});

render();
